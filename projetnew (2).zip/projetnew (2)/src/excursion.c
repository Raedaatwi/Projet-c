#include<stdlib.h>
#include<stdio.h>
#include"excursion.h"
#include<string.h>


void ajouter_excursion(excursion e)
{
FILE *f;
f=fopen("document.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %d %d %d %d %d %d %s \n", e.id,e.destination,e.dt_arrivee.jour,e.dt_arrivee.mois,e.dt_arrivee.annee,e.dt_depart.jour,e.dt_depart.mois,e.dt_depart.annee,e.prix);
fclose(f);
}
}




int modifier_excursion(excursion e)
{
excursion e1;
int retour =-1;
FILE*f;
FILE*f1;
f=fopen("document.txt","r");
f1=fopen("fichier.txt","a+");
while(fscanf(f,"%s %s %d %d %d %d %d %d %s",e1.id, e1.destination,&e1.dt_arrivee.jour,&e1.dt_arrivee.mois,&e1.dt_arrivee.annee,&e1.dt_depart.jour,&e1.dt_depart.mois,&e1.dt_depart.annee,e1.prix)
!=EOF)
{
if (strcmp(e1.id,e.id)==0)
{
fprintf(f1,"%s %s %d %d %d %d %d %d %s \n", e.id,e.destination,e.dt_arrivee.jour,e.dt_arrivee.mois,e.dt_arrivee.annee,e.dt_depart.jour,e.dt_depart.mois,e.dt_depart.annee,e.prix);
retour=1;
}
else
{
fprintf(f1,"%s %s %d %d %d %d %d %d %s \n", e.id,e1.destination,e1.dt_arrivee.jour,e1.dt_arrivee.mois,e1.dt_arrivee.annee,e1.dt_depart.jour,e1.dt_depart.mois,e1.dt_depart.annee,e1.prix);
}
}
fclose(f);
fclose(f1);
remove("document.txt");
rename("fichier.txt","document.txt");
return(retour);
}




int supprimer_excursion( char destinations[])
{
excursion e;
FILE*f;
FILE*f1;
int test=-1;
f=fopen("document.txt","r");
f1=fopen("fichier.txt","a+");
while(fscanf(f,"%s %s %d %d %d %d %d %d %s", e.id,e.destination,&e.dt_arrivee.jour,&e.dt_arrivee.mois,&e.dt_arrivee.annee,&e.dt_depart.jour,&e.dt_depart.mois,&e.dt_depart.annee,e.prix)
!=EOF)
{
if (strcmp(destinations,e.id)!=0)
{
fprintf(f1,"%s %s %d %d %d %d %d %d %s \n \n",e.id,e.destination,e.dt_arrivee.jour,e.dt_arrivee.mois,e.dt_arrivee.annee,e.dt_depart.jour,e.dt_depart.mois,e.dt_depart.annee,e.prix);
}
else
{
test=1;
}
}
fclose(f);
fclose(f1);
remove("document.txt");
rename("fichier.txt","document.txt");
return(test);
}




void afficher_excursion(GtkWidget *liste){
enum
{
ID,
DESTINATION,
DT_DEPART,
DT_ARRIVEE,
PRIX,
COLUMNS
};


GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;




excursion v;


store=NULL;
store=gtk_tree_view_get_model(GTK_TREE_MODEL (liste));
FILE *f;

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" destination",renderer,"text",DESTINATION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" dt depart",renderer,"text",DT_DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" dt arrivee",renderer,"text",DT_ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes(" prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("document.txt", "a+");
 if (f==NULL)
 {

   return;
 }
 else
  {

   
    while(fscanf(f,"%s %s %d %d %d %d %d %d %s \n",v.id,v.destination,&v.dt_arrivee.jour,&v.dt_arrivee.mois,&v.dt_arrivee.annee,&v.dt_depart.jour,&v.dt_depart.mois,&v.dt_depart.annee,v.prix)!=EOF)
     {
char dt_arrivee[50]="";
char dt_depart[50]="";
char r1[20]="";
char r2[20]="";
char r3[20]="";
char r4[20]="";
char r5[20]="";
char r6[20]="";
sprintf(r4,"%d",v.dt_depart.jour);
strcat(dt_depart,r4);
strcat(dt_depart,"/");
sprintf(r5,"%d",v.dt_depart.mois);
strcat(dt_depart,r5);
strcat(dt_depart,"/");
sprintf(r6,"%d",v.dt_depart.annee);
strcat(dt_depart,r6);


sprintf(r1,"%d",v.dt_arrivee.jour);
strcat(dt_arrivee,r1);
strcat(dt_arrivee,"/");
sprintf(r2,"%d",v.dt_arrivee.mois);
strcat(dt_arrivee,r2);
strcat(dt_arrivee,"/");
sprintf(r3,"%d",v.dt_arrivee.annee);
strcat(dt_arrivee,r3);




gtk_list_store_append (store,&iter);
      gtk_list_store_set(store,&iter,ID,v.id,DESTINATION,v.destination,DT_DEPART,dt_depart,DT_ARRIVEE,dt_arrivee,PRIX,v.prix,-1);
     }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);

}  }}
