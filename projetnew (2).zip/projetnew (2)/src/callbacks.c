#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "excursion.h"
#include <string.h>


void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
excursion e;

GtkWidget *id,*destination,*jour1,*jour2,*mois1,*mois2,*annee1,*annee2,*prix;

date dt_arrivee;
date dt_depart;


id=lookup_widget(objet_graphique,"entry3");
destination=lookup_widget(objet_graphique,"entry1");
jour1=lookup_widget(objet_graphique,"spinbutton1");
mois1=lookup_widget(objet_graphique,"spinbutton2");
annee1=lookup_widget(objet_graphique,"spinbutton3");
jour2=lookup_widget(objet_graphique,"spinbutton4");
mois2=lookup_widget(objet_graphique,"spinbutton5");
annee2=lookup_widget(objet_graphique,"spinbutton6");
prix=lookup_widget(objet_graphique,"entry2");
e.dt_arrivee.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
e.dt_arrivee.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
e.dt_arrivee.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
e.dt_depart.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour2));
e.dt_depart.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois2));
e.dt_depart.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee2));
strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(e.destination,gtk_entry_get_text(GTK_ENTRY(destination)));
strcpy(e.prix,gtk_entry_get_text(GTK_ENTRY(prix)));
ajouter_excursion(e);
}


void
on_button2_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *listview;
GtkWidget *w1;
GtkWidget *w2;
w1=lookup_widget(objet_graphique,"window1");
gtk_widget_destroy(w1);
w2 = create_window2 ();
gtk_widget_show(w2);

listview=lookup_widget(w2,"treeview1");
afficher_excursion(listview);
  
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
excursion e;
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(e.id,str_data);
}


void
on_button6_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_button7_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
excursion e;

GtkWidget *id,*destination,*jour1,*jour2,*mois1,*mois2,*annee1,*annee2,*prix;

date dt_arrivee;
date dt_depart;
int acc;
id=lookup_widget(objet_graphique,"entry3");
destination=lookup_widget(objet_graphique,"entry1");
jour1=lookup_widget(objet_graphique,"spinbutton1");
mois1=lookup_widget(objet_graphique,"spinbutton2");
annee1=lookup_widget(objet_graphique,"spinbutton3");
jour2=lookup_widget(objet_graphique,"spinbutton4");
mois2=lookup_widget(objet_graphique,"spinbutton5");
annee2=lookup_widget(objet_graphique,"spinbutton6");
prix=lookup_widget(objet_graphique,"entry2");
e.dt_arrivee.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
e.dt_arrivee.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
e.dt_arrivee.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
e.dt_depart.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour2));
e.dt_depart.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois2));
e.dt_depart.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee2));
strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(e.destination,gtk_entry_get_text(GTK_ENTRY(destination)));
strcpy(e.prix,gtk_entry_get_text(GTK_ENTRY(prix)));
acc=modifier_excursion(e);
}


void
on_button8_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_modifier_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
excursion e;

GtkWidget *id,*destination,*jour1,*jour2,*mois1,*mois2,*annee1,*annee2,*prix;

date dt_arrivee;
date dt_depart;
int acc;
id=lookup_widget(objet_graphique,"entry3");
destination=lookup_widget(objet_graphique,"entry1");
jour1=lookup_widget(objet_graphique,"spinbutton1");
mois1=lookup_widget(objet_graphique,"spinbutton2");
annee1=lookup_widget(objet_graphique,"spinbutton3");
jour2=lookup_widget(objet_graphique,"spinbutton4");
mois2=lookup_widget(objet_graphique,"spinbutton5");
annee2=lookup_widget(objet_graphique,"spinbutton6");
prix=lookup_widget(objet_graphique,"entry2");
e.dt_arrivee.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
e.dt_arrivee.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
e.dt_arrivee.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
e.dt_depart.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour2));
e.dt_depart.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois2));
e.dt_depart.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee2));
strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(e.destination,gtk_entry_get_text(GTK_ENTRY(destination)));
strcpy(e.prix,gtk_entry_get_text(GTK_ENTRY(prix)));
acc=modifier_excursion(e);
}


void
on_supprimer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
excursion e;
GtkWidget *id,*destination,*jour1,*jour2,*mois1,*mois2,*annee1,*annee2,*prix;

date dt_arrivee;
date dt_depart;
int acc;
id=lookup_widget(objet_graphique,"entry3");
destination=lookup_widget(objet_graphique,"entry1");
jour1=lookup_widget(objet_graphique,"spinbutton1");
mois1=lookup_widget(objet_graphique,"spinbutton2");
mois2=lookup_widget(objet_graphique,"spinbutton5");
annee2=lookup_widget(objet_graphique,"spinbutton6");
prix=lookup_widget(objet_graphique,"entry2");
e.dt_arrivee.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour1));
e.dt_arrivee.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois1));
e.dt_arrivee.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee1));
e.dt_depart.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (jour2));
e.dt_depart.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (mois2));
e.dt_depart.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (annee2));
strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(e.destination,gtk_entry_get_text(GTK_ENTRY(destination)));
strcpy(e.prix,gtk_entry_get_text(GTK_ENTRY(prix)));
acc=supprimer_excursion(e.id);
}


void
on_retour_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *w1;
GtkWidget *w2;
w2=lookup_widget(GTK_WIDGET(objet_graphique),"window2");
gtk_widget_destroy(w2);
w1 = create_window1 ();
gtk_widget_show(w1);
}

